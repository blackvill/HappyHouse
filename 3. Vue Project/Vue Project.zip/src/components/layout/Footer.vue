<template>
  <footer>
    <b-row>
      <b-col
        ><br />
        <p>
          HappyHouse final Project<br />
          ㈜HappyHouse 대표 부울경 4반 12조 부산광역시 강서구 송정동
          녹산산업중로 333, <br />
          TEL 1234-1234 FAX 00-0000-0000 MAIL Happyhouse12@ssafy.com
          <br />
        </p>
        <p>@copyRight 부울경 4반 12조</p></b-col
      >
    </b-row>
  </footer>
</template>

<script>
export default {};
</script>

<style scoped>
footer {
  border-top: 1px solid #35495e;
  text-align: center;
  font-size: 16px;
  color: #41b883;
  margin: 100px 0 0 0;
}
</style>
