const replyStore = {
  namespaced: true,
  state: {},
  getters: {},
  mutations: {},
  actions: {},
};

export default replyStore;
