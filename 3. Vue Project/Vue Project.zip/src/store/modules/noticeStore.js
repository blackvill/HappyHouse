const noticeStore = {
    namespaced: true,
    state: {},
    getters: {},
    mutations: {},
    actions: {},
};

export default noticeStore;
