package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.dao.HouseMapDao;
import com.ssafy.happyhouse.model.dto.HouseDealDto;
import com.ssafy.happyhouse.model.dto.HouseInfoDto;
import com.ssafy.happyhouse.model.dto.SidoGugunCodeDto;


@Service
public class HouseMapServiceImpl implements HouseMapService {

	@Autowired
	private SqlSession sqlSession;

	@Override
	public List<SidoGugunCodeDto> getSido() throws Exception {
		return sqlSession.getMapper(HouseMapDao.class).getSido();
	}

	@Override
	public List<SidoGugunCodeDto> getGugunInSido(String sido) throws Exception {
		return sqlSession.getMapper(HouseMapDao.class).getGugunInSido(sido);
	}

	@Override
	public List<HouseInfoDto> getDongInGugun(String gugun) throws Exception {
		return sqlSession.getMapper(HouseMapDao.class).getDongInGugun(gugun);
	}

	@Override
	public List<HouseInfoDto> getAptInDong(String dong) throws Exception {
		return sqlSession.getMapper(HouseMapDao.class).getAptInDong(dong);
	}

	@Override
	public List<HouseDealDto> getDealsInDong(String dong) throws Exception {
		return sqlSession.getMapper(HouseMapDao.class).getDealsInDong(dong);
	}

	@Override
	public List<HouseDealDto> getSearchByAptName(String aptName) throws Exception {
		return sqlSession.getMapper(HouseMapDao.class).getSearchByAptName(aptName);
	}

	@Override
	public List<HouseDealDto> getHouseDealInRange(String swlat, String swlng, String nelat, String nelng)
			throws Exception {
		return sqlSession.getMapper(HouseMapDao.class).getHouseDealInRange(swlat, swlng, nelat, nelng);
	}

	@Override
	public List<HouseDealDto> getSearchByLatLng(String lat, String lng) throws Exception {
		return sqlSession.getMapper(HouseMapDao.class).getSearchByLatLng(lat, lng);
	}

	@Override
	public List<HouseDealDto> getHouseDealInRangeByPrice(String swlat, String swlng, String nelat, String nelng,
			String price) throws Exception {
//		System.out.println("service:"+price);
		return sqlSession.getMapper(HouseMapDao.class).getHouseDealInRangeByPrice(swlat, swlng, nelat, nelng, price);
	}

}
