package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.dto.NoticeDto;

public interface NoticeService {
	List<NoticeDto> searchAll();
	NoticeDto search(String notice_no) ;
	void Notice_Regist(NoticeDto noticeDto);
	void Notice_Update(NoticeDto noticeDto);
	void Notice_Remove(String notice_no);
	void viewCount(String notice_no);  // 조회수 증가.
}
