package com.ssafy.happyhouse.model.dto;

public class QnADto {
	int no;
	String title;
	String user;
	String content;
	
	public QnADto(String title, String user, String content) {
		this.title = title;
		this.user = user;
		this.content = content;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
}
