package com.ssafy.happyhouse.controller;

import java.util.List;

import javax.servlet.http.HttpServlet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.dto.QnADto;
import com.ssafy.happyhouse.model.dto.QnAReplyDto;
import com.ssafy.happyhouse.model.service.QnAService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/qna")
@CrossOrigin(origins = {"*"}, maxAge = 6000)
@Api("Qna 컨트롤러  API V1")
public class QnAController extends HttpServlet {
	@Autowired
	private QnAService service;
	
	private static final String SUCCESS="success";

	@ApiOperation(value="QnA 목록 정보", notes = "QnA 정보를 검색 조건에 맞게 검색한 결과")
	@GetMapping("/list")
	public ResponseEntity<List<QnADto>> searchAll() throws Exception{
		List<QnADto> qna = service.searchAll();
		if(qna!=null && !qna.isEmpty()) {
			return new ResponseEntity<List<QnADto>>(qna, HttpStatus.OK);
		}else {
			return new ResponseEntity<List<QnADto>>(HttpStatus.NO_CONTENT);
		}
	}
	
	@ApiOperation(value="QnA 조회", notes = "QnA번호에 해당하는 도정 정보를 조회")
	@GetMapping("/detail/{no}")
	public ResponseEntity<QnADto> search(@PathVariable int no) throws Exception{
		QnADto qna = service.search(no);
		if(qna!=null ) {
			return new ResponseEntity<QnADto>(qna, HttpStatus.OK);
		}else {
			return new ResponseEntity<QnADto>(HttpStatus.NO_CONTENT);
		}
	}
	
	@ApiOperation(value="QnA 등록", notes = "QnA 정보를 전달받아 등록시킨다.")
	@PostMapping("/regist")
	public ResponseEntity<String> regist(@RequestBody  QnADto qnaDto) throws Exception{
		service.registerQnA(qnaDto);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
	
	@ApiOperation(value="QnA 삭제", notes = "QnA 번호에 해당하는 도정 정보를 삭제한다.")
	@DeleteMapping("/delete/{no}")
	public ResponseEntity<String> remove(@PathVariable int no) throws Exception{
		service.deleteQnA(no);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
	
	@ApiOperation(value="QnA 수정", notes = "QnA 정보를 전달받아 수정시킨다.")
	@PutMapping("/update")
	public ResponseEntity<String> update(@RequestBody  QnADto qnaDto) throws Exception{
		service.updateQnA(qnaDto);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
	
	
	@ApiOperation(value="QnA_reply 조회", notes = "QnA번호에 해당하는 reply 정보를 조회")
	@GetMapping("/reply/detail/{no}")
	public ResponseEntity<List<QnAReplyDto>> searchReply(@PathVariable int no) throws Exception{
		List<QnAReplyDto> qna = service.searchReply(no);
		if(qna!=null ) {
			return new ResponseEntity<List<QnAReplyDto>>(qna, HttpStatus.OK);
		}else {
			return new ResponseEntity<List<QnAReplyDto>>(HttpStatus.NO_CONTENT);
		}
	}
	
	@ApiOperation(value="QnA 답글 등록", notes = "QnA 답글을 등록한다.")
	@PostMapping("/reply/regist")
	public ResponseEntity<String> registReply(@RequestBody  QnAReplyDto qnareplyDto) throws Exception{
		service.registerQnAReply(qnareplyDto);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
	
	@ApiOperation(value="QnA 답글 삭제", notes = "QnA 답글을 삭제한다.")
	@DeleteMapping("/reply/delete/{no}")
	public ResponseEntity<String> removeReply(@PathVariable int no) throws Exception{
		service.deleteQnAReply(no);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
	
	@ApiOperation(value="QnA 답글 수정", notes = "QnA 답글을 수정한다.")
	@PutMapping("/reply/update")
	public ResponseEntity<String> updateReply(@RequestBody  QnAReplyDto qnareplyDto) throws Exception{
		service.updateQnAReply(qnareplyDto);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
}
