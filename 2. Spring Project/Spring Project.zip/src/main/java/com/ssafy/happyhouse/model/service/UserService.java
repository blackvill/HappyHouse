package com.ssafy.happyhouse.model.service;

import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.model.dto.UserDto;

public interface UserService {
	UserDto login(UserDto userDto) throws Exception;
	UserDto getUser(String user_id) throws Exception;
	List<UserDto> listUser() throws Exception;
	void regist(UserDto userDto) throws Exception;
	void update(UserDto user) throws Exception;
	void remove(String id) throws Exception;
}
