package com.ssafy.happyhouse.model.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.dto.HouseDealDto;
import com.ssafy.happyhouse.model.dto.HouseInfoDto;
import com.ssafy.happyhouse.model.dto.SidoGugunCodeDto;

@Mapper
public interface HouseMapDao {

	List<SidoGugunCodeDto> getSido() throws Exception;
	List<SidoGugunCodeDto> getGugunInSido(String sido) throws Exception;
	List<HouseInfoDto> getDongInGugun(String gugun) throws Exception;
	List<HouseInfoDto> getAptInDong(String dong) throws Exception;
	List<HouseDealDto> getSearchByAptName(String aptName) throws Exception;
	List<HouseDealDto> getDealsInDong(String dong) throws Exception;
	List<HouseDealDto> getHouseDealInRange(String swlat, String swlng, String nelat, String nelng) throws Exception;
	List<HouseDealDto> getSearchByLatLng(String lat, String lng) throws Exception;
	List<HouseDealDto> getHouseDealInRangeByPrice(String swlat, String swlng, String nelat, String nelng, String price) throws Exception;
	
}
