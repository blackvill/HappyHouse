package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.happyhouse.model.dao.NoticeDao;
import com.ssafy.happyhouse.model.dto.NoticeDto;
import com.ssafy.happyhouse.model.dto.NoticeException;
import com.ssafy.happyhouse.model.dto.ReplyDto;
@Service
public class NoticeServiceImpl implements NoticeService{
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	private NoticeDao dao;
	
	@Transactional(readOnly = true)
	@Override
	public List<NoticeDto> searchAll() {
	
		return dao.searchAll();
	}
	
	@Transactional(readOnly = true)
	@Override
	public NoticeDto search(String notice_no) {
		return dao.search(notice_no);
	}
	
	@Transactional
	@Override
	public void Notice_Regist(NoticeDto noticeDto) {
		NoticeDto find = dao.search(noticeDto.getNotice_no());
		if(find !=null) throw new NoticeException("이미 등록된 게시글 번호입니다.");
		dao.Notice_Regist(noticeDto);
	}
	
	@Transactional
	@Override
	public void Notice_Update(NoticeDto noticeDto) {
		NoticeDto find = dao.search(noticeDto.getNotice_no());
		if(find ==null) throw new NoticeException("등록되지 않은 Notice_no입니다. 게시글 정보를 수정할 수 없습니다.");
		dao.Notice_Update(noticeDto);
		
	}
	
	@Transactional
	@Override
	public void Notice_Remove(String notice_no) {
		dao.Notice_Remove(notice_no);
		
	}
	
	@Transactional
	@Override
	public void viewCount(String notice_no) {
		System.out.println("service"+notice_no);
		dao.viewCount(notice_no);
	}
}
