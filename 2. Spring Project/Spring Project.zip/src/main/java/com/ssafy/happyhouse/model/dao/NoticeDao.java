package com.ssafy.happyhouse.model.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.dto.NoticeDto;

@Mapper
public interface NoticeDao {
	List<NoticeDto> searchAll();
	NoticeDto search(String notice_no);	
	void Notice_Regist(NoticeDto noticeDto) ;
	void Notice_Update(NoticeDto noticeDto) ;
	void Notice_Remove(String notice_no);
	void viewCount(String notice_no); 
}
