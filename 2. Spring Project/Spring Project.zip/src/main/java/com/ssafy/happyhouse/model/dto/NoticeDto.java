package com.ssafy.happyhouse.model.dto;

public class NoticeDto {
	private String notice_no 	  	 ;   	// 글 번호
	private String notice_title   ;			// 글 제목
	private String notice_content ;			// 글 내용
	private String write_date    ;			// 작성일
	private int view_count    	 ;			// 조회수
	
	public String getNotice_no() {
		return notice_no;
	}
	public void setNotice_no(String notice_no) {
		this.notice_no = notice_no;
	}
	public String getNotice_title() {
		return notice_title;
	}
	public void setNotice_title(String notice_title) {
		this.notice_title = notice_title;
	}
	public String getNotice_content() {
		return notice_content;
	}
	public void setNotice_content(String notice_content) {
		this.notice_content = notice_content;
	}
	public String getWrite_date() {
		return write_date;
	}
	public void setWrite_date(String write_date) {
		this.write_date = write_date;
	}
	public int getView_count() {
		return view_count;
	}
	public void setView_count(int view_count) {
		this.view_count = view_count;
	}
	
}
