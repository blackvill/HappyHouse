package com.ssafy.happyhouse.model.dto;

public class QnAReplyDto {
	int reply_no;
	String content;
	String writer;
	int no;
	public QnAReplyDto(int reply_no, String content, String writer, int no) {
		this.reply_no = reply_no;
		this.content = content;
		this.writer = writer;
		this.no = no;
	}
	public int getReply_no() {
		return reply_no;
	}
	public void setReply_no(int reply_no) {
		this.reply_no = reply_no;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
}
