package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.dto.NoticeDto;
import com.ssafy.happyhouse.model.dto.NoticeException;
import com.ssafy.happyhouse.model.dto.ReplyDto;
import com.ssafy.happyhouse.model.service.NoticeService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


@Api("공지사항을 위한 Controller API V1")
@RestController()
@CrossOrigin(origins = {"*"}, maxAge = 6000)
public class NoticeController {
	private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);
	@Autowired
	private NoticeService service;
	private static final String SUCCESS = "success";
	
	@ExceptionHandler
	public ResponseEntity<String> handler(Exception  e) {	
		logger.debug("ErrorHandler..............................");
		logger.debug("errorMessage............................", e.getMessage());
		e.printStackTrace();
		if( e instanceof NoticeException) {
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.FAILED_DEPENDENCY);
		}else {
			return new ResponseEntity<String>("처리 중 오류 발생",HttpStatus.FAILED_DEPENDENCY);
		}
	}
	@ApiOperation(value ="게시판  조회", notes ="해당 Notice_no 게시판 정보 출력")
	@GetMapping("/notice/{notice_no}")
	public ResponseEntity<NoticeDto> search(@PathVariable String notice_no) {
		logger.debug("search...........................................");
		NoticeDto Notice = service.search(notice_no);
		if(Notice != null) {
			service.viewCount(notice_no);
			return new ResponseEntity<NoticeDto>(Notice, HttpStatus.OK);
		}else
			return new ResponseEntity(HttpStatus.NO_CONTENT);
	}
	
	@ApiOperation(value="게시판 목록 정보", notes = "게시판 정보를 검색 조건에 맞게 검색한 결과")
	@GetMapping("/notice")
	public ResponseEntity<List<NoticeDto>> searchAll(){
		logger.debug("searchAll............................");
		List<NoticeDto> Noticelist = service.searchAll();
		logger.debug("Notices:{}", Noticelist);
		if(Noticelist!=null && !Noticelist.isEmpty()) {
			return new ResponseEntity<List<NoticeDto>>(Noticelist, HttpStatus.OK);
		}else {
			return new ResponseEntity<List<NoticeDto>>(HttpStatus.NO_CONTENT);
		}
	}
	@ApiOperation(value="게시글 등록", notes="게시글을 등록시켜줍니다.")
    @PostMapping("/notice")
    public ResponseEntity<String> regist(@RequestBody NoticeDto noticeDto) {
        service.Notice_Regist(noticeDto);
        return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
    }
	
	@ApiOperation(value ="게시판 글 수정", notes ="해당 게시판 정보를 수정")
	@PutMapping(value = "/notice")
	public ResponseEntity<String> update(@RequestBody NoticeDto noticeDto) throws Exception {
		service.Notice_Update(noticeDto);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
	
	@ApiOperation(value ="게시판 정보삭제", notes ="해당 notice_no 번호를 가진 게시판 글 삭제.")
	@DeleteMapping("/notice/{notice_no}")
	public  ResponseEntity<String> remove(@PathVariable("notice_no") String no) {
		logger.debug("remove...........................................");
		service.Notice_Remove(no);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
}
