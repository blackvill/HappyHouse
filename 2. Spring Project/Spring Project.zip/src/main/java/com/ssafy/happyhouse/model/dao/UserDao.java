package com.ssafy.happyhouse.model.dao;

import java.sql.SQLException;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.dto.UserDto;

@Mapper
public interface UserDao {
	UserDto login(UserDto userDto) throws Exception;
	UserDto idCheck(String id) throws Exception;
	UserDto getUser(String user_id) throws Exception;
	List<UserDto> listUser() throws Exception;
	void regist(UserDto userDto) throws Exception;
	void update(UserDto user) throws Exception;
	void remove(String id);	
}
