package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.dto.BoardDto;
import com.ssafy.happyhouse.model.dto.BoardException;
import com.ssafy.happyhouse.model.dto.ReplyDto;
import com.ssafy.happyhouse.model.service.BoardService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api("게시판을 위한 Controller API V1")
@RestController()
@CrossOrigin(origins = {"*"}, maxAge = 6000)
public class BoardController {
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	@Autowired
	private BoardService service;
	private static final String SUCCESS = "success";
	
	@ExceptionHandler
	public ResponseEntity<String> handler(Exception  e) {	
		logger.debug("ErrorHandler..............................");
		logger.debug("errorMessage............................", e.getMessage());
		e.printStackTrace();
		if( e instanceof BoardException) {
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.FAILED_DEPENDENCY);
		}else {
			return new ResponseEntity<String>("처리 중 오류 발생",HttpStatus.FAILED_DEPENDENCY);
		}
	}
	
	@ApiOperation(value="게시판 목록 정보", notes = "게시판 정보를 검색 조건에 맞게 검색한 결과")
	@GetMapping("/board")
	public ResponseEntity<List<BoardDto>> searchAll(){
		logger.debug("searchAll............................");
		List<BoardDto> Boardlist = service.searchAll();
		logger.debug("Boards:{}", Boardlist);
		if(Boardlist!=null && !Boardlist.isEmpty()) {
			return new ResponseEntity<List<BoardDto>>(Boardlist, HttpStatus.OK);
		}else {
			return new ResponseEntity<List<BoardDto>>(HttpStatus.NO_CONTENT);
		}
	}
	
	@ApiOperation(value ="게시판  조회", notes ="해당 Board_no 게시판 정보 출력")
	@GetMapping("/board/{board_no}")
	public ResponseEntity<BoardDto> search(@PathVariable String board_no) {
		logger.debug("search...........................................");
		BoardDto Board = service.search(board_no);
		if(Board != null) {
			return new ResponseEntity<BoardDto>(Board, HttpStatus.OK);
		}else
			return new ResponseEntity(HttpStatus.NO_CONTENT);
	}
	
	
	@ApiOperation(value="게시글 등록", notes="게시글을 등록시켜줍니다.")
    @PostMapping("/board")
    public ResponseEntity<String> regist(@RequestBody BoardDto boardDto) {
        service.Board_Regist(boardDto);
        return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
    }
	
	@ApiOperation(value ="게시판 글 수정", notes ="해당 게시판 정보를 수정")
	@PutMapping(value = "/board")
	public ResponseEntity<String> update(@RequestBody BoardDto boardDto) throws Exception {
		service.Board_Update(boardDto);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
	
	@ApiOperation(value ="게시판 정보삭제", notes ="해당 board_no 번호를 가진 게시판 글 삭제.")
	@DeleteMapping("/board/{board_no}")
	public  ResponseEntity<String> remove(@PathVariable("board_no") String no) {
		logger.debug("remove...........................................");
		service.Board_Remove(no);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
	
	@ApiOperation(value ="reply(답변) 조회", notes ="해당 Board_no 답변 정보 출력")
	@GetMapping("/reply/{board_no}")
	public ResponseEntity<List<ReplyDto>> reply_search(@PathVariable String board_no) {
		System.out.println(board_no);
		logger.debug("search...........................................");
		List<ReplyDto>  reply = service.Reply_Search(board_no);
		System.out.println(reply.toString());
		if(reply != null) {
			return new ResponseEntity<List<ReplyDto>>(reply, HttpStatus.OK);
		}else
			return new ResponseEntity(HttpStatus.NO_CONTENT);
	}
	
	@ApiOperation(value="Reply 등록", notes="Reply를 등록시켜줍니다.")
	@PostMapping("/reply")
	public ResponseEntity<String> reply_regist(@RequestBody ReplyDto reply) {
		service.Reply_Regist(reply);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
	@ApiOperation(value ="Reply 수정", notes ="해당 Reply 정보를 수정")
	@PutMapping(value = "/reply")
	public ResponseEntity<String> reply_update(@RequestBody ReplyDto reply) throws Exception {
		service.Reply_Update(reply);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
	
	@ApiOperation(value ="Reply 정보삭제", notes ="해당 board_no 번호를 가진 Reply삭제.")
	@DeleteMapping("/reply/{replyno}")
	public  ResponseEntity<String> reply_remove(@PathVariable("replyno") String no) {
		logger.debug("remove...........................................");
		service.Reply_Delete(no);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
}
