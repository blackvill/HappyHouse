package com.ssafy.happyhouse.model.dto;

public class BoardException extends RuntimeException{
public BoardException() {
		
	}
	public BoardException(String msg) {
		super(msg);
	}
}
