package com.ssafy.happyhouse.model.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.dto.BoardDto;
import com.ssafy.happyhouse.model.dto.ReplyDto;

@Mapper
public interface BoardDao {
	List<BoardDto> searchAll();
	BoardDto search(String board_no);	
	void Board_Regist(BoardDto boardDto) ;
	void Board_Update(BoardDto boardDto) ;	
	void Board_Remove(String board_no);
	List<ReplyDto> Reply_Search(String board_no);
	void Reply_Regist(ReplyDto reply);
	void Reply_Update(ReplyDto reply);
	void Reply_Delete(String replyno);
}
