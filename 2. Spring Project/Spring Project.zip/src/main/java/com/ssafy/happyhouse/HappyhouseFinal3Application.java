package com.ssafy.happyhouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappyhouseFinal3Application {

	public static void main(String[] args) {
		SpringApplication.run(HappyhouseFinal3Application.class, args);
	}

}
