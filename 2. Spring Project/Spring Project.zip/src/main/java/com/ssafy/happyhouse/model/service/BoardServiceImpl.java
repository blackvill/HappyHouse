package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.happyhouse.model.dao.BoardDao;
import com.ssafy.happyhouse.model.dto.BoardDto;
import com.ssafy.happyhouse.model.dto.BoardException;
import com.ssafy.happyhouse.model.dto.ReplyDto;
@Service
public class BoardServiceImpl implements BoardService{
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	private BoardDao dao;
	
	
	@Transactional
	public List<BoardDto> searchAll() {
		return dao.searchAll();
	}
	
	@Transactional
	public BoardDto search(String board_no) {
		return dao.search(board_no);
	}
	
	@Transactional
	public void Board_Regist(BoardDto boardDto) {
		BoardDto find = dao.search(boardDto.getBoard_no());
		if(find !=null) throw new BoardException("이미 등록된 게시글 번호입니다.");
		dao.Board_Regist(boardDto);
	}
	
	@Transactional
	public void Board_Update(BoardDto boardDto) {
		BoardDto find = dao.search(boardDto.getBoard_no());
		if(find ==null) throw new BoardException("등록되지 않은 Board_no입니다. 게시글 정보를 수정할 수 없습니다.");
		dao.Board_Update(boardDto);
		
	}
	
	@Transactional
	public void Board_Remove(String board_no) {
		dao.Board_Remove(board_no);
		
	}
	
	
	@Transactional
	public List<ReplyDto> Reply_Search(String board_no) {
		return dao.Reply_Search(board_no);
	}

	@Transactional
	public void Reply_Regist(ReplyDto reply) {
		BoardDto find = dao.search(reply.getBoard_no());
		dao.Reply_Regist(reply);	
	}

	@Transactional
	public void Reply_Update(ReplyDto reply) {
		BoardDto find = dao.search(reply.getBoard_no());
		if(find ==null) throw new BoardException("등록되지 않은 Board_no입니다. 해당 게시글 답변을 수정할 수 없습니다.");
		dao.Reply_Update(reply);	
	}

	@Transactional
	public void Reply_Delete(String replyno) {
		dao.Reply_Delete(replyno);
		
	}

	

}
