package com.ssafy.happyhouse.model.dto;

public class ReplyDto {
	private String replyno		  ; // 답변 번호
	private String user_id    	  ; // 작성자
	private String comment        ; // 답변 내용
	private String replytime       ;	// 답변 등록 일자
	private String board_no 	  ; // 답변 게시글 번호
	public String getReplyno() {
		return replyno;
	}
	public void setReplyno(String replyno) {
		this.replyno = replyno;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getReplytime() {
		return replytime;
	}
	public void setReplytime(String replytime) {
		this.replytime = replytime;
	}
	public String getBoard_no() {
		return board_no;
	}
	public void setBoard_no(String board_no) {
		this.board_no = board_no;
	}
	
	
}
