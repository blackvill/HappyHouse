package com.ssafy.happyhouse.model.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.ssafy.happyhouse.model.dao.UserDao;
import com.ssafy.happyhouse.model.dto.UserDto;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	private UserDao dao;
	
	@Transactional
	public UserDto login(UserDto userDto) throws Exception {
		if(userDto.getUser_id() == null || userDto.getUser_password() == null)
			return null;
		return sqlSession.getMapper(UserDao.class).login(userDto);
	}
	
	//회원 정보 들고옴.
	@Override
	public UserDto getUser(String user_id) throws Exception {
		return sqlSession.getMapper(UserDao.class).getUser(user_id);
	}

	@Override
	public List<UserDto> listUser() throws Exception {
		return sqlSession.getMapper(UserDao.class).listUser();
	}

	@Override
	public void regist(UserDto user) throws Exception {
		dao.regist(user);
	}

	@Override
	public void update(UserDto user) throws Exception {
		System.out.println(user);
		dao.update(user);
	}

	@Override
	public void remove(String id) throws Exception {
		dao.remove(id);	
	}
	
}
