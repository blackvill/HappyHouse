package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.dto.QnADto;
import com.ssafy.happyhouse.model.dto.QnAReplyDto;

public interface QnAService {
	void registerQnA(QnADto qnaDto) throws Exception;
	void deleteQnA(int no) throws Exception;
	QnADto search(int no) throws Exception;
	
	//전체 검색
	public List<QnADto> searchAll()throws Exception;
	void updateQnA(QnADto qnaDto) throws Exception;
	
	/*Qna 답글*/
	void registerQnAReply(QnAReplyDto qnareplyDto) throws Exception;
	void deleteQnAReply(int no) throws Exception;
	List<QnAReplyDto> searchReply(int no) throws Exception;
	void updateQnAReply(QnAReplyDto qnareplyDto) throws Exception;
	
}
