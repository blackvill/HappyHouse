package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.happyhouse.model.dto.QnADto;
import com.ssafy.happyhouse.model.dto.QnAReplyDto;
import com.ssafy.happyhouse.model.dao.QnADao;

@Service
public class QnAServiceImpl implements QnAService {

	@Autowired
	private QnADao dao;
	
	@Transactional
	public void registerQnA(QnADto qnaDto) throws Exception {
		dao.registerQnA(qnaDto);
	}

	@Transactional
	public void deleteQnA(int no) throws Exception {
		dao.deleteQnA(no);
	}

	@Transactional
	public QnADto search(int no) throws Exception {
		return dao.search(no);
	}

	@Transactional
	public List<QnADto> searchAll() throws Exception {
		return dao.searchAll();
	}
	@Transactional
	public void updateQnA(QnADto qnaDto) throws Exception {
		dao.updateQnA(qnaDto);
		
	}

	@Transactional
	public void registerQnAReply(QnAReplyDto qnareplyDto) throws Exception {
		dao.registerQnAReply(qnareplyDto);
		
	}

	@Transactional
	public void deleteQnAReply(int no) throws Exception {
		dao.deleteQnAReply(no);
		
	}

	@Transactional
	public List<QnAReplyDto> searchReply(int no) throws Exception {
		return dao.searchReply(no);
	}

	@Transactional
	public void updateQnAReply(QnAReplyDto qnareplyDto) throws Exception {
		dao.updateQnAReply(qnareplyDto);
	}
	
}
