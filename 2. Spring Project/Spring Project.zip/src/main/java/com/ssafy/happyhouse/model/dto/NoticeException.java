package com.ssafy.happyhouse.model.dto;

public class NoticeException extends RuntimeException{
public NoticeException() {
		
	}
	public NoticeException(String msg) {
		super(msg);
	}
}
