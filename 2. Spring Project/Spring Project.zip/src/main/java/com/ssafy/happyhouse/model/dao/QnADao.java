package com.ssafy.happyhouse.model.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.dto.QnADto;
import com.ssafy.happyhouse.model.dto.QnAReplyDto;

@Mapper
public interface QnADao {
		void registerQnA(QnADto qnaDto) throws Exception;
		void deleteQnA(int no) throws Exception;
		QnADto search(int no) throws Exception;
		
		public List<QnADto> searchAll()throws Exception;
		void updateQnA(QnADto qnaDto) throws Exception;
		
		/*Qna 답글*/
		void registerQnAReply(QnAReplyDto qnareplyDto) throws Exception;
		void deleteQnAReply(int no) throws Exception;
		List<QnAReplyDto> searchReply(int no) throws Exception;
		
		void updateQnAReply(QnAReplyDto qnareplyDto) throws Exception;
		
}
